function toggleMenu() {
  const menu = document.getElementById("dropdownMenu");
  menu.style.display = menu.style.display === "block" ? "none" : "block";
}

function showView(viewId) {
  const views = document.querySelectorAll(".view");
  views.forEach((view) => view.style.display = "none");
  document.getElementById(viewId).style.display = "block";
  document.getElementById("dropdownMenu").style.display = "none";
}

function showSub(subId) {
  const subs = document.querySelectorAll(".sub-section");
  subs.forEach((sub) => sub.style.display = "none");
  document.getElementById(subId).style.display = "block";
}

// Default view on load
window.onload = () => {
  showView('login');

  // Start video if cameraSub is shown later
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then((stream) => {
        const video = document.getElementById('video');
        if (video) video.srcObject = stream;
      })
      .catch((err) => {
        console.error("Camera error:", err);
      });
  }
};
